from tkinter import *
from tkinter import filedialog
from tkinter import ttk
from tkinter.ttk import *
from tkinter import messagebox
import os
import time

root = Tk()
root.title("Shutdown Timer")

# ************************ SETS WINDOW IN CENTER OF SCREEN ************************
# Gets the requested values of the height and widht.
windowHeight = root.winfo_reqheight()
windowWidth = root.winfo_reqwidth()
# Gets both half the screen width/height and window width/height
positionRight = int(root.winfo_screenwidth()/2 - windowWidth/2)
positionDown = int(root.winfo_screenheight()/2 - windowHeight/2)
# Positions the window in the center of the page.
root.geometry("+{}+{}".format(positionRight, positionDown))

def shutdownTimer(*args):
    timer = str(time_input.get())
    if timer == "":
        messagebox.showerror("Error","Input cannot be empty")
    else:
        theTime = int(timer)
        messagebox.showinfo("Shutdown", "Your pc will shutdown in " + timer + " seconds")
        time.sleep(theTime)
        messagebox.showinfo("Shutdown", "Your pc will shutdown now")
        time.sleep(5)
        os.system('shutdown -s')

mainframe = ttk.Frame(root, padding="10 10 10 10")
mainframe.grid(column=0, row=0, sticky=(N, W, E, S))
root.columnconfigure(0, weight=1)
root.rowconfigure(0, weight=1)

timeVal = StringVar()
time_input = ttk.Entry(mainframe, width=15, textvariable=timeVal)
time_input.grid(column=2, row=1, sticky=(W,E))

ttk.Label(mainframe, text="Enter time in seconds").grid(column=1, row=1, sticky=W)
ttk.Button(mainframe, text="Shutdown", command=shutdownTimer).grid(column=3, row=1, sticky=W)

for child in mainframe.winfo_children(): child.grid_configure(padx=5, pady=5)
time_input.focus()

root.bind('<Return>', shutdownTimer)
root.mainloop()

# -- END --
