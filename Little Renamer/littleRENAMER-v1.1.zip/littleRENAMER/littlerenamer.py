from tkinter import *
from tkinter import filedialog
from tkinter import ttk
from tkinter.ttk import *
from tkinter import messagebox
import os

root = Tk()
style = ttk.Style()
# APPLICATION NAME
root.title("Little Renamer")

# ************************ SETS WINDOW IN CENTER OF SCREEN ************************
# Gets the requested values of the height and widht.
windowHeight = root.winfo_reqheight()
windowWidth = root.winfo_reqwidth()
# Gets both half the screen width/height and window width/height
positionRight = int(root.winfo_screenwidth()/2 - windowWidth/2)
positionDown = int(root.winfo_screenheight()/2 - windowHeight/2)
# Positions the window in the center of the page.
root.geometry("+{}+{}".format(positionRight, positionDown))

# STYLES
# style.configure("BW.TLabel", foreground="white")

def selectFolder():
    folder_selected = filedialog.askdirectory()
    path_input.delete(0,END)
    path_input.insert(0,folder_selected)
    return

def getVal(*args):
    filePath = str(path_input.get())
    replaceText = str(replace_input.get())
    raname_text = str(rename_input.get())
    renameFile(filePath, replaceText, raname_text)

def renameFile(filePath, replaceText, raname_text):
    if filePath != "":
        os.chdir(filePath)
        for file in os.listdir(filePath):
            os.rename(file, file.replace(replaceText, raname_text))
        messagebox.showinfo("Complete","Rename Complete!")
    else:
        messagebox.showerror("Error", "File Path Cannot be empty!")


mainframe = ttk.Frame(root, padding="3 3 12 12")
mainframe.grid(column=0, row=0, sticky=(N, W, E, S))
root.columnconfigure(0, weight=1)
root.rowconfigure(0, weight=1)

file_path = StringVar()
replace_text = StringVar()
raname_text = StringVar()

path_input = ttk.Entry(mainframe, width=30, textvariable=file_path)
path_input.grid(column=2, row=1, sticky=(W,E))

replace_input = ttk.Entry(mainframe, width=30, textvariable=replace_text)
replace_input.grid(column=2, row=2, sticky=(W,E))

rename_input = ttk.Entry(mainframe, width=30, textvariable=raname_text)
rename_input.grid(column=2, row=3, sticky=(W,E))

ttk.Button(mainframe, text="Rename", command=getVal).grid(column=3, row=4, sticky=W)
ttk.Button(mainframe, text="Open Folder", command=selectFolder).grid(column=3, row=1, sticky=W)

ttk.Label(mainframe, text="File Path").grid(column=1, row=1, sticky=W)
ttk.Label(mainframe, text="Text to replace").grid(column=1, row=2, sticky=W)
ttk.Label(mainframe, text="New file name").grid(column=1, row=3, sticky=W)
ttk.Label(mainframe, text="Please click button -->").grid(column=2, row=4, sticky=W)

for child in mainframe.winfo_children(): child.grid_configure(padx=5, pady=5)

path_input.focus()
root.bind('<Return>', getVal)

root.mainloop()

# --- END ---
