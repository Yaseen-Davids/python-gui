-- Developed by Yaseen Davids --

In order to run this program, you need to have Python 3.6 or higher installed.
Tkinter and OS libraries were used and needs to be installed as well.

ENJOY!