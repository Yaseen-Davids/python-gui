import os
import shutil

# ENTER FILE PATH
file_path = r''
# ENTER DESTINATION PATH
destination = r''

# CHECK FOLDERS IN DESTINATION
def checkDestPath():
    os.chdir(destination)
    for folder in os.listdir(destination):
        checkFilePath(folder)

# CHECK FILE IN FILE PATH
def checkFilePath(folder):
    os.chdir(file_path)
    for file in os.listdir(file_path):
        theFile = file.split(".")[0]
        secondFile = file.split(".")[1]
        theSeason = file.split(".")
        # IF FOLDER OF FILE FOUND
        if theFile == folder:
            checkSeason(theSeason, folder, file)
        # IF FOLDER OF FILE FOUND
        elif secondFile == folder:
            checkSeason(theSeason, folder, file)

# CHECK SEASON OF SERIES AND MOVE FILE TO UPDATED DESTINATION
def checkSeason(theSeason, folder, file):
    for season in theSeason:
        if season.startswith("S0"):
            seasonNo = season[2]
            series_path = destination + "/" + folder
            os.chdir(series_path)
            for otherFolder in os.listdir(series_path):
                if otherFolder[-1] == seasonNo:
                    os.chdir(file_path)
                    shutil.move(file, destination + '/' + folder + '/' + otherFolder)
                    print("Complete")

# START
checkDestPath()

# -- END --
